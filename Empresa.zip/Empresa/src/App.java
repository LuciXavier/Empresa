import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        List<Produto> Produtos = Arrays.asList(
            new Produto("Camiseta", 30.0),
            new Produto("Calça Jeans", 80.0),
            new Produto("Tênis", 120.0),
            new Produto("Boné", 25.0),
            new Produto("Jaqueta", 150.0),
            new Produto("Bolsa", 95.0),
            new Produto("Ôculos", 140.0),
            new Produto("Chapéu", 29.0),
            new Produto("Moletom", 100.0),
            new Produto("Relógio", 180.0),
            new Produto("Colar", 18.0),
            new Produto("Brincos", 15.0)
        );

        System.out.println("\nLista completa de produtos:\n");
        for (Produto Produto : Produtos) {
            System.out.println(Produto.getNome() + " - R$ " + Produto.getPreco());
        }

        double maxpreco = 50.0;

        displayImperdiveis(Produtos, maxpreco);

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("\nFiltrar por outro preço? (Digite o valor ou 0 para sair): ");
            double userPreco = scanner.nextDouble();

            if (userPreco == 0) {
                System.out.println("Encerrando o programa.");
                break;
            }

            displayImperdiveis(Produtos, userPreco);
        }

        scanner.close();
    }

    public static void displayImperdiveis(List<Produto> Produtos, double maxpreco) {
        System.out.println("\nImperdivéis!!(Preço: R$ " + maxpreco + "):\n");
        Filtro filter = new Filtro();
        List<String> imperdiveis = filter.filterByPrice(Produtos, maxpreco);

        if (imperdiveis.isEmpty()) {
            System.out.println("Nenhum produto encontrado abaixo de R$ " + maxpreco);
        } else {
            for (String ProdutoName : imperdiveis) {
                System.out.println(ProdutoName);
            }
        }
    }
}
