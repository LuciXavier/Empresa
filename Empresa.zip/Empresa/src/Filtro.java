import java.util.ArrayList;
import java.util.List;

public class Filtro {
    public List<String> filterByPrice(List<Produto> products, double maxPreco) {
        List<String> filteredProducts = new ArrayList<>();

        for (Produto product : products) {
            if (product.getPreco() < maxPreco) {
                filteredProducts.add(product.getNome().toUpperCase());
            }
        }
        
        return filteredProducts;
    }
}
